# DirectX 12 Agility SDK Redistributable NuGet Package

This package contains a copy of the DirectX 12 Agility SDK redistributable runtime and its associated development headers. 

For help getting started and other information for the Agility SDK, please see:

https://aka.ms/directx12agility

The included licenses apply to the following files:

- **LICENSE.txt** : applies to all files under `build/native/bin/`
- **LICENSE-CODE.txt** : applies to all files under `build/native/include/`